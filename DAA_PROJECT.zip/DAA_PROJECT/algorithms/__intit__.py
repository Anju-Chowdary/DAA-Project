# This is algorithms/__init__.py
# It's empty because its only purpose is to mark this directory as a Python package.
