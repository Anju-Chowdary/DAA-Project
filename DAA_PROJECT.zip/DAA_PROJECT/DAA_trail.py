import sys
import numpy as np
import random
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import networkx as nx
import time

# Add the project directory to the system path
sys.path.append("C:/Users/pinni/AppData/Local/Programs/Python/Python311/DAA_PROJECT")

# Import modules from the 'algorithms' package
from algorithms import aco, genetic, simulated_annealing, fifo, round_robin, tabu, nsga2

class JobShopSchedulingApp:
    def __init__(self, master):
        self.master = master
        master.title("Job Shop Scheduling Simulator")

        self.frame = ttk.Frame(master)
        self.frame.pack(padx=10, pady=10)

        ttk.Label(self.frame, text="Enter Jobs (format: machine,duration; ...):").pack()
        self.jobs_entry = ttk.Entry(self.frame, width=50)
        self.jobs_entry.pack()
        self.jobs_entry.insert(0, "0,3;1,2;2,2")

        ttk.Label(self.frame, text="Number of Machines:").pack()
        self.num_machines_entry = ttk.Entry(self.frame, width=10)
        self.num_machines_entry.pack()
        self.num_machines_entry.insert(0, "3")

        self.algorithm_choice = ttk.Combobox(self.frame, values=["ACO", "Genetic Algorithm", "Simulated Annealing", "FIFO", "Round Robin", "Tabu Search", "NSGA-II"])
        self.algorithm_choice.pack()
        self.algorithm_choice.set("ACO")

        self.run_button = ttk.Button(self.frame, text="Run Selected Algorithm", command=self.run_selected_algorithm)
        self.run_button.pack()

        self.compare_button = ttk.Button(self.frame, text="Compare All Algorithms", command=self.compare_algorithms)
        self.compare_button.pack()

        self.robustness_button = ttk.Button(self.frame, text="Run Robustness Analysis", command=self.run_robustness_analysis)
        self.robustness_button.pack()

        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvasTkAgg(self.figure, master)
        self.canvas.get_tk_widget().pack(side='left', fill='both', expand=True)

        self.graph_figure, self.graph_ax = plt.subplots()
        self.graph_canvas = FigureCanvasTkAgg(self.graph_figure, master)
        self.graph_canvas.get_tk_widget().pack(side='right', fill='both', expand=True)

    def run_selected_algorithm(self):
        jobs_input = self.jobs_entry.get()
        num_machines = int(self.num_machines_entry.get())
        algorithm = self.algorithm_choice.get()
        jobs = [(int(part.split(',')[0]), int(part.split(',')[1])) for part in jobs_input.split(';')]
        
        start_time = time.time()
        if algorithm == "ACO":
            schedule, makespan = aco.run(jobs, num_machines)
        elif algorithm == "Genetic Algorithm":
            schedule, makespan = genetic.run(jobs, num_machines)
        elif algorithm == "Simulated Annealing":
            schedule, makespan = simulated_annealing.run(jobs, num_machines)
        elif algorithm == "FIFO":
            schedule, makespan = fifo.run(jobs, num_machines)
        elif algorithm == "Round Robin":
            schedule, makespan = round_robin.run(jobs, num_machines)
        elif algorithm == "Tabu Search":
            schedule, makespan = tabu.run(jobs, num_machines)
        elif algorithm == "NSGA-II":
            schedule, (makespan, total_idle_time) = nsga2.run(jobs, num_machines)
            print(f"Total Idle Time: {total_idle_time}")
        end_time = time.time()

        execution_time = end_time - start_time
        time_complexity, space_complexity = self.get_complexity(algorithm)

        self.display_schedule(schedule, makespan)
        self.display_complexity(execution_time, time_complexity, space_complexity)

    def compare_algorithms(self):
        jobs_input = self.jobs_entry.get()
        num_machines = int(self.num_machines_entry.get())
        jobs = [(int(part.split(',')[0]), int(part.split(',')[1])) for part in jobs_input.split(';')]
        
        algorithms = {
            "ACO": aco.run,
            "Genetic Algorithm": genetic.run,
            "Simulated Annealing": simulated_annealing.run,
            "FIFO": fifo.run,
            "Round Robin": round_robin.run,
            "Tabu Search": tabu.run,
            "NSGA-II": nsga2.run
        }

        results = {}
        complexities = {}
        for name, func in algorithms.items():
            start_time = time.time()
            schedule, output = func(jobs, num_machines)
            end_time = time.time()

            if isinstance(output, tuple):
                makespan, total_idle_time = output
                print(f"{name} - Makespan: {makespan}, Idle Time: {total_idle_time}")
            else:
                makespan = output

            execution_time = end_time - start_time
            results[name] = makespan
            complexities[name] = (execution_time, *self.get_complexity(name))

        # Plotting results
        names = list(results.keys())
        values = list(results.values())
        
        plt.figure(figsize=(10, 5))
        plt.bar(names, values, color='maroon')
        plt.xlabel('Algorithms')
        plt.ylabel('Makespan (Total Completion Time)')
        plt.title('Comparison of Scheduling Algorithms by Makespan')
        plt.show()

        # Display complexities
        self.display_all_complexities(complexities)

    def get_complexity(self, algorithm):
        complexities = {
            "ACO": ("O(n^2)", "O(n)"),
            "Genetic Algorithm": ("O(g * n)", "O(n)"),
            "Simulated Annealing": ("O(n^2)", "O(n)"),
            "FIFO": ("O(n)", "O(n)"),
            "Round Robin": ("O(n)", "O(n)"),
            "Tabu Search": ("O(n^2)", "O(n)"),
            "NSGA-II": ("O(p * g * n)", "O(p)")
        }
        return complexities.get(algorithm, ("Unknown", "Unknown"))

    def simulate_disruptions(self, schedule, disruption_rate=0.1):
        disrupted_schedule = schedule[:]
        num_disruptions = int(len(schedule) * disruption_rate)
        for _ in range(num_disruptions):
            idx = random.randint(0, len(schedule) - 1)
            disrupted_schedule[idx] = (disrupted_schedule[idx][0], disrupted_schedule[idx][1] + random.randint(1, 5), disrupted_schedule[idx][2] + random.randint(1, 5), disrupted_schedule[idx][3])
        return disrupted_schedule

    def run_robustness_analysis(self):
        jobs_input = self.jobs_entry.get()
        num_machines = int(self.num_machines_entry.get())
        algorithm = self.algorithm_choice.get()
        jobs = [(int(part.split(',')[0]), int(part.split(',')[1])) for part in jobs_input.split(';')]

        if algorithm == "ACO":
            schedule, makespan = aco.run(jobs, num_machines)
        elif algorithm == "Genetic Algorithm":
            schedule, makespan = genetic.run(jobs, num_machines)
        elif algorithm == "Simulated Annealing":
            schedule, makespan = simulated_annealing.run(jobs, num_machines)
        elif algorithm == "FIFO":
            schedule, makespan = fifo.run(jobs, num_machines)
        elif algorithm == "Round Robin":
            schedule, makespan = round_robin.run(jobs, num_machines)
        elif algorithm == "Tabu Search":
            schedule, makespan = tabu.run(jobs, num_machines)
        elif algorithm == "NSGA-II":
            schedule, (makespan, total_idle_time) = nsga2.run(jobs, num_machines)

        disrupted_schedule = self.simulate_disruptions(schedule)
        disrupted_makespan = max(job[2] for job in disrupted_schedule)
        disrupted_idle_time = sum(job[1] for job in disrupted_schedule) - disrupted_makespan

        print(f"Original Makespan: {makespan}")
        print(f"Disrupted Makespan: {disrupted_makespan}")
        print(f"Original Idle Time: {total_idle_time if algorithm == 'NSGA-II' else 'N/A'}")
        print(f"Disrupted Idle Time: {disrupted_idle_time}")

    def display_schedule(self, schedule, makespan):
        self.ax.clear()
        self.ax.set_title(f'Job Schedule (Min Makespan: {makespan})')
        colors = plt.cm.viridis(np.linspace(0, 1, len(schedule)))
        for job in schedule:
            machine_id, start_time, end_time, job_id = job
            self.ax.broken_barh([(start_time, end_time - start_time)], (machine_id * 10, 9), facecolors=random.choice(colors))
        self.ax.set_yticks([10 * i + 5 for i in range(int(self.num_machines_entry.get()))])
        self.ax.set_yticklabels([f'Machine {i}' for i in range(int(self.num_machines_entry.get()))])
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Machine')
        self.canvas.draw()

        # Display the dependency graph
        self.display_graph(schedule)

    def display_graph(self, schedule):
        G = nx.DiGraph()
        for job in schedule:
            _, _, _, job_id = job
            G.add_node(job_id, label=f"Job {job_id}")

        # Assuming each job depends on the previous job
        for i in range(len(schedule) - 1):
            G.add_edge(schedule[i][3], schedule[i+1][3])

        self.graph_ax.clear()
        pos = nx.spring_layout(G)
        nx.draw(G, pos, ax=self.graph_ax, with_labels=True, node_color='skyblue', node_size=500)
        self.graph_ax.set_title('Job Dependencies')
        self.graph_canvas.draw()

    def display_complexity(self, execution_time, time_complexity, space_complexity):
        messagebox.showinfo("Algorithm Complexity", 
                            f"Execution Time: {execution_time:.4f} seconds\n"
                            f"Time Complexity: {time_complexity}\n"
                            f"Space Complexity: {space_complexity}")

    def display_all_complexities(self, complexities):
        complexity_info = ""
        for algorithm, (execution_time, time_complexity, space_complexity) in complexities.items():
            complexity_info += (f"{algorithm}:\n"
                                f"  Execution Time: {execution_time:.4f} seconds\n"
                                f"  Time Complexity: {time_complexity}\n"
                                f"  Space Complexity: {space_complexity}\n\n")
        messagebox.showinfo("Algorithm Complexities", complexity_info)

if __name__ == "__main__":
    root = tk.Tk()
    app = JobShopSchedulingApp(root)
    root.mainloop()
